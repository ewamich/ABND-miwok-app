package com.example.musicalstructureapp;

public class Song {

    private String mTitle;
    private String mBandName;
    public boolean isFavourite;

    public Song(String title, String bandName){
        mTitle = title;
        mBandName = bandName;
        isFavourite = false;
    }

    public String getTitle(){

        return mTitle;
    }

    public String getBandName(){
        return mBandName;
    }
}
