package com.example.musicalstructureapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //create words arrayList
        ArrayList<Song> songs = new ArrayList<Song>();
        songs.add(new Song("red", "weṭeṭṭi"));
        songs.add(new Song("red", "weṭeṭṭi"));
        songs.add(new Song("red", "weṭeṭṭi"));

        SongAdapter adapter = new SongAdapter(this, songs);

        ListView listview = (ListView) findViewById(R.id.list);

        listview.setAdapter(adapter);
    }
}
