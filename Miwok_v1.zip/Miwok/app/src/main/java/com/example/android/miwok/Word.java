package com.example.android.miwok;

import android.content.Context;
import android.media.MediaPlayer;

public class Word {

    private String mMiwokTranslation;
    private String mDefaultTranslation;
    private int mImage = NO_IMAGE_PROVIDED;
    private static final int NO_IMAGE_PROVIDED = -1;
    private int mAudio;

    public Word(String defaultTranslation, String miwokTranslation, int audio){
        mDefaultTranslation = defaultTranslation;
        mMiwokTranslation = miwokTranslation;
        mAudio = audio;
    }

    public Word(String defaultTranslation, String miwokTranslation, int image, int audio){
        mDefaultTranslation = defaultTranslation;
        mMiwokTranslation = miwokTranslation;
        mImage = image;
        mAudio = audio;

    }

    public String getMiwokTranslation(){
        return mMiwokTranslation;
    }

    public String getDefaultTranslation(){
        return mDefaultTranslation;
    }
    public int getImage() {
        return mImage;
    }
    public boolean hasImage(){
        return mImage != NO_IMAGE_PROVIDED;
    }
    public int getAudioResource() {
        return mAudio;
    }
}
